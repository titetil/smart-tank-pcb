Board Name:  Smart Tank PCB, v1.1

Company:  TI Automotive

Thickness:  0.093"

Copper Weight:  1.0 oz

Number of Layers:  10

**All mounting holes must be plated**

